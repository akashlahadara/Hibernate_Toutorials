package test;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class FindeNthSalar {

	public static void main(String[] args)
	{
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		String hql="select salary from Employee order by salary desc";
		Query q=s.createQuery(hql);
		q.setMaxResults(1);
		q.setFirstResult(1);
		Query q1=s.createQuery(hql);
		q1.setMaxResults(1);
		q1.setFirstResult(2);
		Integer SecHighestSal=(Integer) q.uniqueResult();
		Integer thirdHighestSal=(Integer) q1.uniqueResult();
		System.out.println("Second highest salary is"+SecHighestSal+"\n Third highest salary is"+thirdHighestSal);
		s.close();
		sf.close();
	}

}
