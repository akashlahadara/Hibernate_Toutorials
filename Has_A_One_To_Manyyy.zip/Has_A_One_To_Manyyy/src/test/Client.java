package test;

import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import beans.Car;
import beans.Enginee;

public class Client {

	public static void main(String[] args) 
	{
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		
		Enginee e=new Enginee();
		e.setEnineename("Good");
		e.setModelyear(2015);
		e.setWarrenty(3);
		
		
		Enginee e1=new Enginee();
		e1.setEnineename("Very Good");
		e1.setModelyear(2018);
		e1.setWarrenty(5);
		
		
		
		Enginee e2=new Enginee();
		e2.setEnineename("Brilent");
		e2.setModelyear(2020);
		e2.setWarrenty(7);
		
		
		Enginee e3=new Enginee();
		e3.setEnineename("Good");
		e3.setModelyear(2015);
		e3.setWarrenty(3);
		
		
		ArrayList<Enginee> al=new ArrayList<Enginee>();
		al.add(e);
		al.add(e1);
		
		ArrayList<Enginee> al1=new ArrayList<Enginee>();
		al1.add(e2);
		al.add(e3);
		
		Car c=new Car();
		c.setCarname("Audi");
		c.setEnginne(al);
		
		Car c1=new Car();
		c1.setCarname("Thar");
		c1.setEnginne(null);
		c.setEnginne(al1);
		
		Car c2=new Car();
		c2.setCarname("Mahanidra");
		c2.setEnginne(al);
		
		s.save(c);
		s.save(c1);
		s.save(c2);
		Transaction t=s.beginTransaction();
		t.commit();
		s.close();
		sf.close();
		System.out.println("Data Save Succesfully");
		
	}

}
