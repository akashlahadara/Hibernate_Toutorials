package test;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import beans.Car;
import beans.Enginee;

public class SelectData {

	public static void main(String[] args)
	{

		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Query q=s.createQuery("from Car");
		List<Car> l=q.getResultList();
		Iterator<Car> itr=l.iterator();
		while(itr.hasNext())
		{
			Car car=itr.next();
			System.out.println("Car Name is "+car.getCarname());
			
			List<Enginee> l1=car.getEnginne();
			Iterator<Enginee> itr1=l1.iterator();
			while (itr1.hasNext())
			{
				Enginee enginee = (Enginee) itr1.next();
				System.out.println("Enginne Name is "+enginee.getEnineename());
				System.out.println("Enginne modelyear is "+enginee.getModelyear());
				System.out.println("Enginne warrenty  is "+enginee.getWarrenty());
			}
			
		}
		s.close();
		sf.close();
		System.out.println("Data Fatch Succesfully ");
	}

}
