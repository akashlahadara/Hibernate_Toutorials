package beans;

public class Address 
{
	private int id;
	private String cityname;
	private String streetname;
	private int zipcode;
	private Employee employee;  
	public Address(int id, String cityname, String streetname, int zipcode,Employee employee) {
		super();
		this.id = id;
		this.cityname = cityname;
		this.streetname = streetname;
		this.zipcode = zipcode;
		this.employee=employee;
	}
	public Employee getEmployee() {
		return employee;
	}
	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCityname() {
		return cityname;
	}
	public void setCityname(String cityname) {
		this.cityname = cityname;
	}
	public String getStreetname() {
		return streetname;
	}
	public void setStreetname(String streetname) {
		this.streetname = streetname;
	}
	public int getZipcode() {
		return zipcode;
	}
	public void setZipcode(int zipcode) {
		this.zipcode = zipcode;
	}
	public Address() {
		// TODO Auto-generated constructor stub
	}
	
}
