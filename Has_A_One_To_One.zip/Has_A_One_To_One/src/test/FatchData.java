package test;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import beans.Address;
import beans.Employee;

public class FatchData {

	public static void main(String[] args)
	{
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Query q=s.createQuery("from Employee");
		List<Employee> l=q.getResultList();
		Iterator<Employee> itr=l.iterator();
		while (itr.hasNext())
		{
			Employee emp = (Employee)itr.next();
			System.out.println("Employee Name is "+emp.getName()+"\n Employee Email is "+emp.getEmail());
			System.out.println("Employee Marks is "+emp.getMarks()+"\n Employee Rank is "+emp.getName());
			Address ads=emp.getAddress();
			System.out.println("Employee Cityname is "+ads.getCityname()+"\n Employee Streetname is "+ads.getStreetname());
			System.out.println("Employee Zipcode is "+ads.getZipcode());
			s.close();
			sf.close();
			System.out.println("Data Fatch Successfully");
		}
	}

}
