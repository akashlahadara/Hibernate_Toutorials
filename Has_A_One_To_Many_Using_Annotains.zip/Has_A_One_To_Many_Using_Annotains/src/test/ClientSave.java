package test;

import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import beans.Course;
import beans.Student;

public class ClientSave {

	public static void main(String[] args)
	{
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		Course c=new Course();
		c.setName("Java");
		c.setCdur("2 Months");
		c.setFee(5000);
		
		
		Course c1=new Course();
		c1.setName("Adv Java");
		c1.setCdur("1 Months");
		c1.setFee(3000);
		
		Course c2=new Course();
		c2.setName("Hibernate");
		c2.setCdur("1 Months");
		c2.setFee(4000);
		
		Course c3=new Course();
		c3.setName("SpringBoot&Microservice");
		c3.setCdur("3 Months");
		c3.setFee(9000);
		
		ArrayList<Course> al=new ArrayList<Course>();
		al.add(c);
		al.add(c2);
		al.add(c3);
		
		
		
		ArrayList<Course> al1=new ArrayList<Course>();
		al1.add(c);
		al1.add(c2);
		
		
		
		Student st=new Student();
		st.setName("Akash");
		st.setCourse(al);
		
		Student st1=new Student();
		st1.setName("Seema");
		st.setCourse(al1);
		
		Student st2=new Student();
		st2.setName("Divya");
		st2.setCourse(al);
		
		s.save(st);
		s.save(st1);
		s.save(st2);

		
		t.commit();
		
		
		s.close();
		sf.close();
		
		System.out.println("Data Save Successfully");
	}

}
