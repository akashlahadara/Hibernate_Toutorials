package test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import beans.Student;

public class Client 
{

	public static void main(String[] args)
	{
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		System.out.println("Document Validate Succesfully");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Student st=new Student();
		st.setId(101);
		st.setName("Akash");
		st.setEmail("akash@gmail.com");
		st.setAddress("DN");
		st.setMarks(297);
		//this state of object is transient
		Transaction t=s.beginTransaction();
		s.save(st);
		//this state of object is persistent
		t.commit();
		s.evict(st);
		//this object State is Detached
		s.close();
		sf.close();
		System.out.println("Data Save Succesfully in Database");
	}

}
