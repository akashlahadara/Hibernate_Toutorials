package test;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;

import beans.Employee;

public class SelectAvgSal {

	public static void main(String[] args)
	{
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Criteria c=s.createCriteria(Employee.class);
		Projection p= Projections.avg("salary");
		c.setProjection(p);
		double avgsal=(double)c.uniqueResult();
		System.out.println("Avg sal is"+avgsal);
		s.close();
		sf.close();
		System.out.println("Data Fatch Succesfully");
	}
}
