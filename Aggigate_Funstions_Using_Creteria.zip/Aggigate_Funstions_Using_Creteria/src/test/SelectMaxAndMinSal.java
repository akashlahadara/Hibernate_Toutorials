package test;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import beans.Employee;

public class SelectMaxAndMinSal {

	public static void main(String[] args) 
	{

		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Criteria c=s.createCriteria(Employee.class);
		Projection p= Projections.min("salary"); //for minimumn salary
		Projection p1= Projections.max("salary"); //for minimumn salary
		c.setProjection(p);
		c.setProjection(p1);
		Integer minsal=(Integer)c.uniqueResult();
		Integer maxsal=(Integer)c.uniqueResult();
		System.out.println("minsal sal is"+minsal+"\n max sal is"+maxsal);
		s.close();
		sf.close();
		System.out.println("Data Fatch Succesfully");
	}

}
