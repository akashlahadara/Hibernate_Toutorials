package test;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HQL_Dump_table_to_Table
{
	public static void main(String[] args)
	{
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		String hql="insert into NewStudent(id,name,email,address) select id,name,email,address  from OldStudent";
		Query q=s.createQuery(hql);
		int i=q.executeUpdate();
		System.out.println("No of row affected "+i);
		s.close();
		sf.close();
	}
}
