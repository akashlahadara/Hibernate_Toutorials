package beans;

public class HREmp extends Employee
{
	private int wh;

	public int getWh() {
		return wh;
	}

	public void setWh(int wh) {
		this.wh = wh;
	}

	public HREmp() {
		super();
		// TODO Auto-generated constructor stub
	}

	public HREmp(int id, String name, String email, String address, int salary,int wh) {
		super(id, name, email, address, salary);
		this.wh=wh;
	}
	
}	

