package beans;

public class SoftwareEmp extends Employee
{
	private String orm;
	private String framework;
	public SoftwareEmp() 
	{
		super();
		
	}
	public SoftwareEmp(int id, String name, String email, String address, int salary,String orm,String framework) 
	{
		super(id, name, email, address, salary);
		this.orm=orm;
		this.framework=framework;
	}
	public String getOrm() {
		return orm;
	}
	public void setOrm(String orm) {
		this.orm = orm;
	}
	public String getFramework() {
		return framework;
	}
	public void setFramework(String framework) {
		this.framework = framework;
	}
	
	
}
