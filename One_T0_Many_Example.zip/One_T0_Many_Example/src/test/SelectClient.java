package test;

import java.util.Iterator;
import java.util.List;

import javax.sql.rowset.serial.SQLOutputImpl;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.tool.schema.SourceType;

import beans.Answer;
import beans.Question;

public class SelectClient
{
	public static void main(String[] args)
	{
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Query q1=s.createQuery("From Question");
		List<Question> list=q1.getResultList();
		
	    Iterator<Question> itr=list.iterator();  
	    while(itr.hasNext())
	    {  
	        Question q=itr.next();  
	        System.out.println("Question Name: "+q.getQname());  
	          
	        //printing answers  
	        List<Answer> list2=q.getAnswers();  
	        Iterator<Answer> itr2=list2.iterator();  
	        while(itr2.hasNext())
	        {
	        	Answer a=itr2.next();
	            System.out.println(a.getAnswername()+":"+a.getPostedBy());
	        }  
	    }
		s.close();
		sf.close();
		
	}
}
