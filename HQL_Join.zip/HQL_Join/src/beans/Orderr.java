package beans;

public class Orderr 
{
	private int id;
	private String oname;
	private String odesc;
	private int oquty;
	
	public Orderr(int id, String oname, String odesc, int oquty) {
		super();
		this.id = id;
		this.oname = oname;
		this.odesc = odesc;
		this.oquty = oquty;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getOname() {
		return oname;
	}

	public void setOname(String oname) {
		this.oname = oname;
	}

	public String getOdesc() {
		return odesc;
	}

	public void setOdesc(String odesc) {
		this.odesc = odesc;
	}

	public int getOquty() {
		return oquty;
	}

	public void setOquty(int oquty) {
		this.oquty = oquty;
	}

	public Orderr()
	{
		
	}
}
