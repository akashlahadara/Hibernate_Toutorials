package test;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Client 
{
	public static void main(String[] args) 
	{
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		String hql="select p.pname,p.pdesc,p.pprice,o.oname from Product p inner join Orderr o on p.pid=o.id";
		Query q=s.createQuery(hql);
		List<Object> str=q.list();
		for(Object name:str)
		{
			Object arr[]=(Object[])name;
			System.out.println(arr[0]);
			System.out.println(arr[1]);
			System.out.println(arr[2]);
			System.out.println(arr[3]);
		}
		
		t.commit();
		s.close();
		sf.close();
	}
}
