package test;

import javax.persistence.TypedQuery;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import beans.Employee;

import java.util.*;
public class FatchUpdate
{
	public static void main(String[] args)
	{
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		TypedQuery q=s.getNamedQuery("findEmployeeByName");
		q.setParameter("name","Akash");   
		List<Employee> employee=q.getResultList();
		Iterator<Employee> itr=employee.iterator();
		while(itr.hasNext())
		{
			Employee e=itr.next();
			System.out.println(e);    
		}
		s.close();
		sf.close();
		System.out.println("Data Fatch Succesfully");
	}
}
