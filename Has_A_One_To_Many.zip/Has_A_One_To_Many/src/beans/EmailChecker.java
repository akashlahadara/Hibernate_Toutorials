package beans;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class EmailChecker {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/database_name";
    private static final String DB_USER = "username";
    private static final String DB_PASSWORD = "password";

    public static boolean doesEmailExist(String email) {
        boolean exists = false;
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            // Establish database connection
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);

            // Prepare SQL query
            String sql = "SELECT COUNT(*) FROM users WHERE email = ?";
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, email);

            // Execute query
            rs = stmt.executeQuery();

            // Check if email exists
            if (rs.next()) {
                int count = rs.getInt(1);
                if (count > 0) {
                    exists = true;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            // Close resources
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return exists;
    }

    public static void main(String[] args) {
        String emailToCheck = "example@example.com";
        boolean emailExists = doesEmailExist(emailToCheck);
        if (emailExists) {
            System.out.println("Email exists in the database.");
        } else {
            System.out.println("Email does not exist in the database.");
        }
    }
}
