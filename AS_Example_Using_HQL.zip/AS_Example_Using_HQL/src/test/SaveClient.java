package test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import beans.Employee;

public class SaveClient {

	public static void main(String[] args)
	{
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		Employee st=new Employee(101,"Akash","akash@gmail.com","DN",55000,5000);
		Employee st1=new Employee(102,"Divya","divya@gmail.com","DN",60000,5000);
		Employee st2=new Employee(103,"Rohit","rohit@gmail.com","DN",65000,5000);
		s.save(st);
		s.save(st1);
		s.save(st2);
		t.commit();
		s.close();
		sf.close();
		System.out.println("Data Save Succesfully");
	}

}
