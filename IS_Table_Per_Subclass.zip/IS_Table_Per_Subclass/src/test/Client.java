package test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import beans.Employee;
import beans.HREmp;
import beans.SoftwareEmp;
import beans.TesterEmp;


public class Client {

	public static void main(String[] args)
	{
		Configuration cfg=new Configuration();
		//cfg.configure("resources/hibernate.cfg.xml"); //for oracle file
		cfg.configure("resources/mysql.cfg.xml"); //for mysql file
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		SoftwareEmp se=new SoftwareEmp(101,"Rohit","rohit_s@gmail.com", "DN", 50000,"Hibernate","SpringBOOt");
		SoftwareEmp se1=new SoftwareEmp(102,"Divya","divya@gmail.com", "DN", 45000,"Hibernate","SpringBOOt");
		SoftwareEmp se2=new SoftwareEmp(103,"Rohit","rohit_j@gmail.com", "DN", 40000,"Hibernate","SpringBOOt");
		SoftwareEmp se3=new SoftwareEmp(104,"Shreya","shreya@gmail.com", "DN", 35000,"Hibernate","SpringBOOt");
		SoftwareEmp se4=new SoftwareEmp(105,"Seema","seema@gmail.com", "RJ", 30000,"Hibernate","SpringBOOt");
		SoftwareEmp se5=new SoftwareEmp(106,"Arun","arun@gmail.com", "DN", 25000,"Hibernate","SpringBOOt");
		SoftwareEmp se6=new SoftwareEmp(107,"Vishal","vishal@gmail.com", "DN", 20000,"Hibernate","SpringBOOt");
		SoftwareEmp se7=new SoftwareEmp(108,"Akash","akash@gmail.com", "DN", 15000,"Hibernate","SpringBOOt");
		Transaction t=s.beginTransaction();
		s.save(se);
		s.save(se1);
		s.save(se2);
		s.save(se3);
		s.save(se4);
		s.save(se5);
		s.save(se6);
		s.save(se7);
		TesterEmp tes=new TesterEmp(109,"Chiru","chiru@gmail.com", "TG", 10000,"Silenimum");
		TesterEmp tes1=new TesterEmp(110,"Meghan","meghan@gmail.com", "TG", 5000,"SJF");
		s.save(tes);
		s.save(tes1);
		HREmp hr=new HREmp(111,"Vijay","vijay@gmail.com", "TG", 10000,8);
		HREmp hr1=new HREmp(112,"Laxmi","laxmi@gmail.com", "TG", 10000,8);
		s.save(hr);
		s.save(hr1);
		t.commit();
		s.close();
		sf.close();
		System.out.println("Data Save Succesfully");
	}

}
