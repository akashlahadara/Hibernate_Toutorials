package beans;

public class Course 
{
	private int id;
	private String coursename;
	private int fee;
	private String dur;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCoursename() {
		return coursename;
	}
	public void setCoursename(String coursename) {
		this.coursename = coursename;
	}
	public int getFee() {
		return fee;
	}
	public void setFee(int fee) {
		this.fee = fee;
	}
	public String getDur() {
		return dur;
	}
	public void setDur(String dur) {
		this.dur = dur;
	}
	public Course() {
		System.out.println("Course Class Object Created");
	}
	public Course(int id, String coursename, int fee, String dur) {
		super();
		this.id = id;
		this.coursename = coursename;
		this.fee = fee;
		this.dur = dur;
	}
	
}
