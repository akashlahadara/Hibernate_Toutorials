package beans;

import java.util.List;
import java.util.Set;

public class Student 
{
	private int id;
	private String name;
	private List<Course> course;
	public Student()
	{
		System.out.println("Student Class Object Created");
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setCourse(List<Course> course) {
		this.course = course;
	}
	public List<Course> getCourse() {
		return course;
	}
	
}
