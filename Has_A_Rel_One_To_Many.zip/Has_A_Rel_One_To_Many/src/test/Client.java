package test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.event.spi.SaveOrUpdateEvent;

import beans.Course;
import beans.Student;


public class Client {

	public static void main(String[] args)
	{
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		System.out.println("Docuemnts Validate Succesfully");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		
		Course c=new Course();
		c.setCoursename("Hibernate");
		c.setDur("1 Months");
		c.setFee(5000);
		
		
		Course c1=new Course();
		c1.setCoursename("Spring FrameWork");
		c1.setDur("2 Months");
		c1.setFee(10000);
		
		Course c2=new Course();
		c2.setCoursename("Spring Boot FrameWork");
		c2.setDur("1 Months");
		c2.setFee(6000);
		
		
		Course c3=new Course();
		c3.setCoursename("Spring FrameWork");
		c3.setDur("20 Days");
		c3.setFee(3000);
		
		ArrayList<Course> al=new ArrayList<Course>();
		al.add(c1);
		al.add(c);
		al.add(c2);
		al.add(c3);
		
		
		ArrayList<Course> al1=new ArrayList<Course>();
		al1.add(c1);
		al1.add(c3);
		
		
		ArrayList<Course> al2=new ArrayList<Course>();
		al2.add(c1);
		al2.add(c2);
		al2.add(c3);
		
		Student st=new Student();
		st.setName("Akash");
		st.setCourse(al);
		
		Student st1=new Student();
		st1.setName("Seema");
		st.setCourse(al1);
		
		Student st2=new Student();
		st2.setName("Divya");
		st2.setCourse(al2);
		
		s.save(st);
		s.save(st1);
		s.save(st2);

		Transaction t=s.beginTransaction();
		t.commit();
		s.close();
		sf.close();
		System.out.println("Data Save Succesfully");
	}

}
