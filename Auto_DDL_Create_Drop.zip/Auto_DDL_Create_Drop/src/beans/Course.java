package beans;

public class Course
{
	private int cid;
	private String cname;
    private int cfee;
    private int cduration;
    public void setCduration(int cduration) {
		this.cduration = cduration;
	}
    public int getCduration() {
		return cduration;
	}
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public int getCfee() {
		return cfee;
	}
	public void setCfee(int cfee) {
		this.cfee = cfee;
	}
	
	
}
