package test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import beans.Student;

public class Client 
{

	public static void main(String[] args)
	{
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		System.out.println("Document Validate Succesfully");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Student st=new Student();
		//this state of object is transient
		st.setId(102);
		st.setName("Seema");
		st.setEmail("seema@gmail.com");
		st.setAddress("RJ");
		st.setMarks(297);
		Transaction t=s.beginTransaction();
		s.save(st);
		//this state of object is persistent
		t.commit();
		s.close();
		sf.close();
		System.out.println("Data Save Succesfully in Database");
	}

}
