package test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import beans.Student;

public class Client {

	public static void main(String[] args)
	{
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Student st=new Student();
		st.setId(101);
		st.setName("Rohit");
		st.setEmail("Rohit@gmail.com");
		st.setAddress("DN");
		st.setRank(1);
		s.saveOrUpdate(st);
		
		Student st1=new Student();
		st1.setId(102);
		st1.setName("Divya");
		st1.setEmail("divya@gmail.com");
		st1.setAddress("DN");
		st1.setRank(2);
		s.saveOrUpdate(st1);
		
		Student st2=new Student();
		st2.setId(103);
		st2.setName("Akash");
		st2.setEmail("akash@gmail.com");
		st2.setAddress("DN");
		st2.setRank(5);
		
		s.saveOrUpdate(st2);
		Transaction t=s.beginTransaction();
		t.commit();
		s.close();
		sf.close();
		System.out.println("Data Insert/Update Succesfully");
	}

}
