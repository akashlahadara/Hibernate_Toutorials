package beans;

public class Product 
{
	private int pid;
	private String pname;
	private String pdesc;
	private int pprice;
	private int pwarrenty;
	public Product(int pid, String pname, String pdesc, int pprice, int pwarrenty) {
		super();
		this.pid = pid;
		this.pname = pname;
		this.pdesc = pdesc;
		this.pprice = pprice;
		this.pwarrenty = pwarrenty;
	}
	public int getPid() {
		return pid;
	}
	public void setPid(int pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPdesc() {
		return pdesc;
	}
	public void setPdesc(String pdesc) {
		this.pdesc = pdesc;
	}
	public int getPprice() {
		return pprice;
	}
	public void setPprice(int pprice) {
		this.pprice = pprice;
	}
	public int getPwarrenty() {
		return pwarrenty;
	}
	public void setPwarrenty(int pwarrenty) {
		this.pwarrenty = pwarrenty;
	}
	public Product()
	{
		
	}
	//select p.pname,p.pdesc,p.pprice,o.oname from product p inner join orderr o on p.pid=o.id;
}
