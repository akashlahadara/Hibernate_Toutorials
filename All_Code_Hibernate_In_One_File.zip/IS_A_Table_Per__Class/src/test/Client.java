package test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import beans.HomeLoan;

public class Client {

	public static void main(String[] args) 
	{

		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml"); //for oracle file
		//cfg.configure("resources/mysql.cfg.xml"); //for mysql file
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		HomeLoan hl=new HomeLoan(101,500000,5,"homeloan",(int) 8.5,"DivyaNagar");
	}

}
