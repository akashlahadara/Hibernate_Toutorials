package beans;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class Loan 
{
	private int loanid;
	private int loanamount;
	private int loantenure;
	private String loanname;
	private int interstrate;
}
