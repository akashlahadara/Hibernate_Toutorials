package beans;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.Setter;


@NoArgsConstructor
@Setter
@Getter
public class HomeLoan extends Loan 
{
	private String cityname;

	public HomeLoan(int loanid, int loanamount, int loantenure, String loanname, int interstrate,String cityname) {
		super(loanid, loanamount, loantenure, loanname, interstrate);
		this.cityname=cityname;
		// TODO Auto-generated constructor stub
	}
	
	
}
