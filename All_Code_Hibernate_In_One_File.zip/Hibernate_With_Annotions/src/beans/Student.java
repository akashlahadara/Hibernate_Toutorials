package beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Entity
@Table(name="student007",schema="system")
@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Student
{
	@Id
	@Column
	private int id;
	@Column
	private String email;
	@Column
	private String name;
	@Column
	private String address;
}
