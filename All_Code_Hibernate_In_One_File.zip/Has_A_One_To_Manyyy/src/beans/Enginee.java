package beans;

public class Enginee 
{
	public Enginee()
	{
		System.out.println("Car Object Created");
	}
	private int id;
	private String enineename;
	private int modelyear;
	private int warrenty;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEnineename() {
		return enineename;
	}
	public void setEnineename(String enineename) {
		this.enineename = enineename;
	}
	public int getModelyear() {
		return modelyear;
	}
	public void setModelyear(int modelyear) {
		this.modelyear = modelyear;
	}
	public int getWarrenty() {
		return warrenty;
	}
	public void setWarrenty(int warrenty) {
		this.warrenty = warrenty;
	}
	
}
