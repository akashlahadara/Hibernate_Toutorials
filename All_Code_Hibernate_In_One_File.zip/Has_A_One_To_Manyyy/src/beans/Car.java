package beans;
import java.util.*;
public class Car 
{
	private int id;
	private String carname;
	private List<Enginee> enginne;
	public Car()
	{
		System.out.println("Car Object Created");
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCarname() {
		return carname;
	}
	public void setCarname(String carname) {
		this.carname = carname;
	}
	public List<Enginee> getEnginne() {
		return enginne;
	}
	public void setEnginne(List<Enginee> enginne) {
		this.enginne = enginne;
	}
	
}
