package test;

import java.util.Iterator;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import beans.Course;
import beans.Student;

public class FatchData {

	public static void main(String[] args)
	{

		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Query q=s.createQuery("from Student");
		List<Student> l=q.getResultList();
		Iterator< Student> itr=l.iterator();
		while (itr.hasNext())
		{
			Student student = (Student) itr.next();
			System.out.println("Student Names is "+student.getName());
			List<Course> l2=student.getCourse();
		    Iterator<Course> itr2=l2.iterator();
		    while (itr2.hasNext()) 
		    {
				Course course = (Course) itr2.next();
				System.out.println("Course List is "+course.getCoursename());
			}
		}
		s.close();
		sf.close();
		System.out.println("Data Fatch Succesfully");
	}

}
