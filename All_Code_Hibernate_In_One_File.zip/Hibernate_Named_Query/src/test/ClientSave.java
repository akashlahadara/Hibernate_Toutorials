package test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import beans.Employee;

public class ClientSave {

	public static void main(String[] args)
	{
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Employee st=new Employee();
		st.setId(101);
		st.setName("Akash");
		st.setEmail("akash@gmail.com");
		st.setAddress("DN");
		st.setSalary(50000);
		st.setCommession(5000);
		Employee st1=new Employee();
		st1.setId(102);
		st1.setName("Divya");
		st1.setEmail("divya@gmail.com");
		st1.setAddress("DN");
		st1.setSalary(45000);
		st1.setCommession(5000);
		s.save(st1);
		s.save(st);
		Transaction t=s.beginTransaction();
		t.commit();
		s.close();
		sf.close();
		System.out.println("Data Insert Succesfully");
	}

}

