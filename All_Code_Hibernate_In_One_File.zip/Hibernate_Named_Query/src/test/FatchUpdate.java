package test;

import javax.persistence.TypedQuery;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import beans.Employee;

import java.util.*;
public class FatchUpdate
{
	public static void main(String[] args)
	{
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		TypedQuery q= s.getNamedQuery("totalsalary");
		System.out.println("value of Query is "+q.toString());
		q.setParameter("id",1);  
		List<Employee> employee=q.getResultList();
		System.out.println("value of employee "+employee);
		/*Iterator<Employee> itr=employee.iterator();
		System.out.println("value of employee itr is "+itr);
		while(itr.hasNext())
		{
			Employee e=itr.next();
			System.out.println("select salary+commission as totalsalary  from employee001 "+e);    
		}
		*/
		s.close();
		sf.close();
		System.out.println("Data Fatch Succesfully");
	}
}
