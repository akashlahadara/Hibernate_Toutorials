package test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import beans.Student;

public class Client {

	public static void main(String[] args)
	{
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Student st=new Student();
		st.setId(104);
		st.setName("Seema");
		st.setEmail("seema@gmail.com");
		st.setAddress("RJ");
		st.setRank(8);
		Student st1=new Student();
		st1.setId(105);
		st1.setName("Vishal");
		st1.setEmail("vishal@gmail.com");
		st1.setAddress("DN");
		st1.setRank(14);
		s.persist(st1);
		s.persist(st);
		Transaction t=s.beginTransaction();
		t.commit();
		s.close();
		sf.close();
		System.out.println("Data Insert Succesfully");
	}

}
