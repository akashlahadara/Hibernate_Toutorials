package test;

import java.util.ArrayList;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import beans.Answer;
import beans.Question;

public class Client 
{
	public static void main(String[] args) 
	{
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		Question q=new Question();
		q.setQname("What is Java");
		Question q1=new Question();
		q1.setQname("What is Servlet");
		Answer a=new Answer();
		a.setAnswername("Java is a programming language");  
		a.setPostedBy("Akash Sharma");
		Answer a1=new Answer();
		a1.setAnswername("Java is a Platform");  
		a1.setPostedBy("Seema Sharma");
		Answer a2=new Answer();
		a2.setAnswername("Servlet is an Interface");  
		a2.setPostedBy("Akash Sharma");
		Answer a3=new Answer();
		a3.setAnswername("Servlet is an Interface");  
		a3.setPostedBy("Seema Sharma");
		ArrayList<Answer> list1=new ArrayList<Answer>();  
		list1.add(a);  
		list1.add(a1);    
		ArrayList<Answer> list2=new ArrayList<Answer>();  
		list2.add(a2);  
		list2.add(a3); 
		s.save(q);
		s.save(q1);
		s.save(a);
		s.save(a1);
		s.save(a2);
		s.save(a3);
		t.commit();
		s.close();
		sf.close();
		System.out.println("Data Saved Succesfully");
	}
}
