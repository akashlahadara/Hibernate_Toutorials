package beans;

public class TesterEmp extends Employee
{
	private String tool;

	public String getTool() {
		return tool;
	}

	public void setTool(String tool) {
		this.tool = tool;
	}

	public TesterEmp() {
		super();
		
	}

	public TesterEmp(int id, String name, String email, String address, int salary,String tool) {
		super(id, name, email, address, salary);
		this.tool=tool;
	}
	
}
