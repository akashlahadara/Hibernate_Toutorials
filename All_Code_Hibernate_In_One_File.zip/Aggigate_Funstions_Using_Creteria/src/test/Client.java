package test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import beans.Employee;


public class Client {

	public static void main(String[] args)
	{
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Employee e=new Employee(101,"Akash","akash@gmail.com",5000);
		Employee e1=new Employee(102,"Vishal","vishal@gmail.com",10000);
		Employee e2=new Employee(103,"Rohit","rohit_s@gmail.com",50000);
		Employee e3=new Employee(104,"Rohit","rohit_j@gmail.com",15000);
		Employee e4=new Employee(105,"Arun","arun@gmail.com",20000);
		Employee e5=new Employee(106,"Divya","divya@gmail.com",25000);
		Employee e6=new Employee(107,"Seema","seema@gmail.com",30000);
		Employee e7=new Employee(108,"Shreya","shreya@gmail.com",35000);
		s.save(e);
		s.save(e1);
		s.save(e2);
		s.save(e3);
		s.save(e4);
		s.save(e5);
		s.save(e6);
		s.save(e7);
		Transaction t=s.beginTransaction();
		t.commit();
		s.close();
		sf.close();
		System.out.println("Data Insert Succesfully");
	}

}
