package test;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class FindeNthMinSalar {

	public static void main(String[] args)
	{
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		String hql="select salary From Employee order by salary asc";
		Query q=s.createQuery(hql);	
		q.setMaxResults(1);
		q.setFirstResult(1);
		Integer secondlowSal=(Integer)q.uniqueResult();
		System.out.println("Second lowest salary is"+secondlowSal);
		s.close();
		sf.close();
		System.out.println("Data Fatch Succesfully");
	}

}
