package controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import beans.Student;

@WebServlet("/reg")
public class StudentController extends HttpServlet {
	
	SessionFactory sf;
	public void init() throws ServletException 
	{
		
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		sf=cfg.buildSessionFactory();
		System.out.println("Session Factory Init");
		super.init();
	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException 
	{
		
		String name=req.getParameter("name");
		String email=req.getParameter("email");
		int rank=Integer.parseInt(req.getParameter("rank"));
		int marks=Integer.parseInt(req.getParameter("marks"));
		Student st=new Student(0,"akash","akash@gmail.com",297,10);
		Session s=sf.openSession();
		int pk=(Integer)s.save(st);
		Transaction t=s.beginTransaction();
		t.commit();
		s.close();
		resp.getWriter().println("register success and id is");
		System.out.println("Data Save Successfully"+pk);
	}
	
	@Override
	
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
	{
		// TODO Auto-generated method stub
		super.doPost(req, resp);
	}
	@Override
	public void destroy() {
		sf.close();
		super.destroy();
	}

}
