package beans;

public class Vote {

}
