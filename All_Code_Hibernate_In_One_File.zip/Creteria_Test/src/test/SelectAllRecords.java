package test;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import beans.Employee;

public class SelectAllRecords {

	public static void main(String[] args)
	{
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Criteria c=s.createCriteria(Employee.class);
		List<Employee> l=c.list();
		for(Employee e:l)
		{
			System.out.println("id is"+e.getId());
			System.out.println("Name is"+e.getName());
			System.out.println("Email is"+e.getEmail());
			System.out.println("Salary is"+e.getSalary());
		}
		s.close();
		sf.close();
		System.out.println("Data Fatch Succesfully");
	}
}
