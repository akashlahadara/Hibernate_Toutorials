package test;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;

import beans.Employee;

public class SelectOperationUsingRestrsitionWhereClause {

	public static void main(String[] args) 
	{

		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Criteria c=s.createCriteria(Employee.class);
	    //Criterion cc=Restrictions.eq("id",101); //for where clause is equal to 
	   // c.add(cc);
		//System.out.println("id is"+e.getId()+ "\n name is " +e.getName()+ "\n email is "+e.getEmail() + "\n salary is"+e.getSalary() );
	   // Employee e=(Employee)c.uniqueResult();
	    Criterion cc=Restrictions.gt("salary",1000); //for where clause is less than greater than etc to 
	    c.add(cc);
	    List<Employee> list=c.list();
	    for(Employee e:list)
	    {
	    	System.out.println("id is"+e.getId()+ "\n name is " +e.getName()+ "\n email is "+e.getEmail() + "\n salary is"+e.getSalary());
	    }
	    s.close();
	    sf.close();
	    System.out.println("Data Fatch Successfully");
	}

}
