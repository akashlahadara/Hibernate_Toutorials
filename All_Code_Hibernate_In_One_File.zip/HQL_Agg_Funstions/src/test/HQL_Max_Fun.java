package test;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class HQL_Max_Fun {

	public static void main(String[] args)
	{
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		String hql="select max(salary) from Employee";
		String hql1="select min(salary) from Employee";
		String hql2="select count(salary) from Employee";
		Query q=s.createQuery(hql);
		Query q1=s.createQuery(hql1);
		Query q2=s.createQuery(hql2);
		Integer max=(Integer) q.uniqueResult();
		System.out.println("max  salary is "+max);
		Integer min=(Integer) q1.uniqueResult();
		System.out.println("min  salary is "+min);
		Long count=(Long) q2.uniqueResult();
		System.out.println("count  salary is "+count);
		s.close();
		sf.close();
	}

}
