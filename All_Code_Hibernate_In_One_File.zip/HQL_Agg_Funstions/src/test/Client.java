package test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import beans.Employee;

public class Client
{
	public static void main(String[] args)
	{
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		System.out.println("Table Created Succesfully");
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		Employee e=new Employee(101,"akash","akash@gmail.com","DN",5000);
		Employee e1=new Employee(102,"seema","seema@gmail.com","RJ",10000);
		Employee e2=new Employee(103,"arun","arunh@gmail.com","DN",15000);
		Employee e3=new Employee(104,"vishal","vishal@gmail.com","DN",20000);
		Employee e4=new Employee(105,"shreya","shreya@gmail.com","DN",25000);
		Employee e5=new Employee(106,"jrohit","rohit_j@gmail.com","DN",30000);
		Employee e6=new Employee(107,"divya","divya@gmail.com","DN",35000);
		Employee e7=new Employee(108,"rohit","rohit_s@gmail.com","DN",50000);
		s.save(e);
		s.save(e1);
		s.save(e2);
		s.save(e3);
		s.save(e4);
		s.save(e5);
		s.save(e6);
		s.save(e7);
		t.commit();
		System.out.println("Data Save Succesfully");
		s.close();
		sf.close();
	}
}
