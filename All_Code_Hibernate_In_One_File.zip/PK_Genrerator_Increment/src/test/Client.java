package test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import beans.BookMovie;

public class Client {

	public static void main(String[] args) 
	{
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		BookMovie bm=new BookMovie();
		bm.setMoviename("RRR");
		bm.setSeatno(25);
		bm.setShowtime("10AM");
		Transaction t=s.beginTransaction();
		s.save(bm);
		t.commit();
		sf.close();
		s.close();
		System.out.println("Movie Ticket Booking Is Successfully Completed");
	}

}
