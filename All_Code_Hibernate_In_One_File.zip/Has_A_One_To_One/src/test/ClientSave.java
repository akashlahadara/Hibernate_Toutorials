package test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import beans.Address;
import beans.Employee;

public class ClientSave {

	public static void main(String[] args) 
	{
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
	   
	    
	   
	    
	    Address a1=new Address();
	    a1.setCityname("DivyaNagar");
	    a1.setStreetname("Krishan Chowk");
	    a1.setZipcode(111008);
	    
	    Employee e=new Employee();
	    e.setName("Akash");
	    e.setEmail("akash@gmail.com");
	    e.setMarks(297);
	    e.setRanks(7);
	    e.setAddress(a1);
	    
	    Employee e2=new Employee();
	    e2.setName("Divya");
	    e2.setEmail("divya@gmail.com");
	    e2.setMarks(499);
	    e2.setRanks(2);
	    e.setAddress(a1);
	    
	    
	    Address a2=new Address();
	    a2.setCityname("Raigarh");
	    a2.setStreetname("Ram Chowk");
	    a2.setZipcode(110087);
	    
	    Employee e1=new Employee();
	    e1.setName("Seema");
	    e1.setEmail("seema@gmail.com");
	    e1.setMarks(497);
	    e1.setRanks(8);
	    e.setAddress(a2);
	    s.save(e);
	    s.save(e1);
	    s.save(e2);
	    s.save(a1);
	    s.save(a2);
	    t.commit();
	    s.close();
	    sf.close();
	    System.out.println("Data Save Successfully");
	}

}
