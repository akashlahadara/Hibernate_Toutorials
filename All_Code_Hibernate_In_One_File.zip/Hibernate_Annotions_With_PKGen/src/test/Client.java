package test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import beans.Student;

public class Client {

	public static void main(String[] args) 
	{
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		Transaction t=s.beginTransaction();
		Student str=new Student();
		Student str1=new Student();
		Student str2=new Student();
		str.setName("Akash");
		str.setEmail("deepak@gmail.com");
		str.setAddress("DN");
		str1.setName("Deepak");
		str1.setEmail("akash@gmail.com");
		str2.setAddress("DN");
		str2.setName("Karan");
		str2.setEmail("karan@gmail.com");
		str1.setAddress("DN");
		s.save(str);
		s.save(str1);
		s.save(str2);
		t.commit();
		s.close();
		sf.close();
		System.out.println("Data Save Succesfully");
	}

}
