package test;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class FindeNthMinSalar {

	public static void main(String[] args)
	{
		Configuration cfg=new Configuration();
		cfg.configure("resources/hibernate.cfg.xml");
		SessionFactory sf=cfg.buildSessionFactory();
		Session s=sf.openSession();
		String hql="select salary from Employee order by salary asc";
		//to find second lowest salary
		Query q=s.createQuery(hql);
		q.setFirstResult(1);
		q.setMaxResults(1);
		//to find 4 lowest salary
		Query q1=s.createQuery(hql);
		q1.setFirstResult(3);
		q1.setMaxResults(1);
		Integer secondlowSal=(Integer)q.uniqueResult();
		Integer fourthlowSal=(Integer)q1.uniqueResult();
		System.out.println("Second lowests salary is"+secondlowSal+"\nfourth lowest salry is"+fourthlowSal);
		s.close();
		sf.close();
		System.out.println("Data Fatch Succesfully");
	}

}
